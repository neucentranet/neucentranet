import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "NeucentraNet — Internet Cepat, Stabil, Terintegrasi",
  description:
    "ISP modern Indonesia dengan layanan internet rumah, bisnis, dan streaming lokal terintegrasi. Kecepatan tinggi, latensi rendah, dukungan lokal 24/7.",
  keywords: [
    "ISP Indonesia",
    "internet cepat",
    "internet rumah",
    "internet bisnis",
    "NeucentraNet",
  ],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id">
      <body className="bg-surface-950 text-slate-200 font-body antialiased">
        {children}
      </body>
    </html>
  );
}
