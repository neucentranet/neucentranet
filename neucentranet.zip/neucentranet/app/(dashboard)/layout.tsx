// Future: Dashboard layout with auth guard, sidebar, etc.
export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen bg-surface-950 text-slate-200">
      {/* Future: Sidebar + Topbar */}
      <main>{children}</main>
    </div>
  );
}
