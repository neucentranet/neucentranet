// Future: Customer dashboard — billing, usage stats, tickets, etc.
export default function DashboardPage() {
  return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="text-center space-y-4">
        <h1 className="text-3xl font-display font-bold text-gradient">
          Dashboard Pelanggan
        </h1>
        <p className="text-slate-400">Segera hadir — dalam pengembangan.</p>
      </div>
    </div>
  );
}
