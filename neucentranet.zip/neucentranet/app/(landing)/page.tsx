import { Navbar } from "@/components/sections/Navbar";
import { Hero } from "@/components/sections/Hero";
import { Services } from "@/components/sections/Services";
import { Pricing } from "@/components/sections/Pricing";
import { Coverage } from "@/components/sections/Coverage";
import { Advantages } from "@/components/sections/Advantages";
import { CTA } from "@/components/sections/CTA";
import { Footer } from "@/components/sections/Footer";

export default function LandingPage() {
  return (
    <main className="min-h-screen bg-surface-950 overflow-x-hidden">
      <Navbar />
      <Hero />
      <Services />
      <Pricing />
      <Coverage />
      <Advantages />
      <CTA />
      <Footer />
    </main>
  );
}
