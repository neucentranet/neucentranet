import React from "react";
import { Section, SectionHeader } from "@/components/ui/Section";

interface Advantage {
  icon: React.ReactNode;
  title: string;
  description: string;
  metric?: string;
  metricLabel?: string;
}

const advantages: Advantage[] = [
  {
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
        <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    ),
    title: "Kecepatan Tinggi",
    description: "Teknologi fiber optik GPON terkini menghadirkan koneksi simetris hingga 1 Gbps tanpa degradasi kualitas.",
    metric: "1 Gbps",
    metricLabel: "Maks. Kecepatan",
  },
  {
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    ),
    title: "Koneksi Stabil",
    description: "Infrastruktur redundan dengan multi-path routing memastikan koneksi Anda tetap stabil 24 jam penuh.",
    metric: "99.9%",
    metricLabel: "Uptime Garansi",
  },
  {
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
        <circle cx="12" cy="12" r="10" />
        <polyline points="12 6 12 12 16 14" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    ),
    title: "Latensi Rendah",
    description: "Point of Presence (PoP) lokal strategis memastikan latensi ultra-rendah untuk gaming, VoIP, dan video conference.",
    metric: "<5ms",
    metricLabel: "Latensi Lokal",
  },
  {
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
        <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" strokeLinecap="round" />
        <circle cx="9" cy="7" r="4" strokeLinecap="round" />
        <path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75" strokeLinecap="round" />
      </svg>
    ),
    title: "Dukungan Lokal",
    description: "Tim teknisi berpengalaman siap membantu Anda kapan saja. Respons cepat, solusi nyata, tanpa agen luar negeri.",
    metric: "24/7",
    metricLabel: "Dukungan Teknis",
  },
  {
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
        <rect x="2" y="3" width="20" height="14" rx="2" strokeLinecap="round" />
        <path d="M8 21h8M12 17v4" strokeLinecap="round" />
        <path d="M7 8l3 3 5-5" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    ),
    title: "Manajemen Mudah",
    description: "Dashboard pelanggan berbasis web & aplikasi mobile untuk pantau penggunaan, tagihan, dan tiket dukungan.",
    metric: "1 App",
    metricLabel: "Semua Kendali",
  },
  {
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
        <path d="M12 2L2 7l10 5 10-5-10-5z" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M2 17l10 5 10-5M2 12l10 5 10-5" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    ),
    title: "Ekosistem Digital",
    description: "Bukan sekadar ISP — platform digital terintegrasi dengan streaming lokal, layanan cloud, dan solusi bisnis.",
    metric: "3-in-1",
    metricLabel: "Layanan Terintegrasi",
  },
];

export const Advantages: React.FC = () => {
  return (
    <Section id="keunggulan" className="relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-brand-950/10 via-transparent to-transparent pointer-events-none" />

      <SectionHeader
        eyebrow="Keunggulan Kami"
        title="Mengapa Memilih"
        titleHighlight="NeucentraNet?"
        description="Kami bukan sekadar penyedia internet. Kami adalah mitra digital yang tumbuh bersama Anda."
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {advantages.map((adv, index) => (
          <div
            key={adv.title}
            className="group relative p-6 rounded-2xl border border-white/[0.05] bg-white/[0.02] hover:bg-white/[0.04] hover:border-brand-600/20 transition-all duration-300 animate-fade-up"
            style={{ animationDelay: `${index * 80}ms` }}
          >
            {/* Hover glow corner */}
            <div className="absolute top-0 right-0 w-20 h-20 rounded-2xl bg-brand-600/0 group-hover:bg-brand-600/5 transition-all duration-300 pointer-events-none" />

            <div className="flex items-start gap-4">
              {/* Icon */}
              <div className="w-12 h-12 rounded-xl bg-brand-600/10 border border-brand-600/20 flex items-center justify-center text-brand-400 flex-shrink-0 group-hover:bg-brand-600/15 group-hover:border-brand-500/30 transition-all duration-300">
                {adv.icon}
              </div>

              {/* Metric */}
              {adv.metric && (
                <div className="ml-auto text-right flex-shrink-0">
                  <div className="font-mono font-bold text-lg text-gradient leading-none">{adv.metric}</div>
                  <div className="text-xs text-slate-600 font-mono mt-0.5">{adv.metricLabel}</div>
                </div>
              )}
            </div>

            <h3 className="font-display font-bold text-white mt-4 mb-2">{adv.title}</h3>
            <p className="text-slate-500 text-sm leading-relaxed">{adv.description}</p>
          </div>
        ))}
      </div>
    </Section>
  );
};
