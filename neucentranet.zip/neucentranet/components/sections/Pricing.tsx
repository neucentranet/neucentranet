import React from "react";
import { Section, SectionHeader } from "@/components/ui/Section";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";

interface PricingPlan {
  id: string;
  name: string;
  tagline: string;
  price: number;
  priceUnit: string;
  speed: string;
  popular?: boolean;
  badge?: string;
  features: string[];
  notIncluded?: string[];
  ctaLabel: string;
  ctaVariant: "primary" | "secondary" | "outline";
}

const plans: PricingPlan[] = [
  {
    id: "basic",
    name: "Basic",
    tagline: "Ideal untuk kebutuhan sehari-hari",
    price: 199000,
    priceUnit: "/bulan",
    speed: "50 Mbps",
    badge: undefined,
    features: [
      "Kecepatan hingga 50 Mbps",
      "Tanpa batas kuota",
      "WiFi Router termasuk",
      "Dukungan teknis reguler",
      "Akses streaming lokal",
    ],
    notIncluded: ["IP Dedicated", "SLA prioritas"],
    ctaLabel: "Pilih Basic",
    ctaVariant: "outline",
  },
  {
    id: "pro",
    name: "Pro",
    tagline: "Pilihan terbaik untuk keluarga aktif",
    price: 349000,
    priceUnit: "/bulan",
    speed: "200 Mbps",
    popular: true,
    badge: "Terpopuler",
    features: [
      "Kecepatan hingga 200 Mbps",
      "Tanpa batas kuota",
      "WiFi 6 Router termasuk",
      "Dukungan teknis prioritas",
      "Akses streaming lokal HD",
      "1 IP Publik gratis",
    ],
    ctaLabel: "Pilih Pro",
    ctaVariant: "primary",
  },
  {
    id: "ultra",
    name: "Ultra",
    tagline: "Performa maksimal, tanpa kompromi",
    price: 599000,
    priceUnit: "/bulan",
    speed: "1 Gbps",
    badge: "Kecepatan Penuh",
    features: [
      "Kecepatan hingga 1 Gbps",
      "Tanpa batas kuota",
      "Mesh WiFi 6E termasuk",
      "Dukungan 24/7 VIP",
      "Akses streaming lokal 4K",
      "IP Dedicated",
      "SLA 99.9% terjamin",
    ],
    ctaLabel: "Pilih Ultra",
    ctaVariant: "secondary",
  },
];

const formatRupiah = (amount: number) =>
  new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);

interface PricingCardProps {
  plan: PricingPlan;
  index: number;
}

const PricingCard: React.FC<PricingCardProps> = ({ plan, index }) => {
  if (plan.popular) {
    return (
      <div
        className="relative rounded-2xl p-px bg-gradient-to-b from-brand-500/60 via-accent-cyan/20 to-brand-700/40 animate-fade-up"
        style={{ animationDelay: `${index * 120}ms` }}
      >
        {/* Popular ribbon */}
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 z-10">
          <span className="bg-brand-600 text-white text-xs font-mono font-medium px-4 py-1 rounded-full shadow-glow-blue">
            ⭐ {plan.badge}
          </span>
        </div>

        <div className="rounded-[15px] bg-gradient-to-b from-brand-950/95 to-surface-950 p-8 h-full flex flex-col">
          <PricingContent plan={plan} />
        </div>
      </div>
    );
  }

  return (
    <Card
      hover
      padding="lg"
      className="flex flex-col animate-fade-up"
    >
      <PricingContent plan={plan} />
    </Card>
  );
};

const PricingContent: React.FC<{ plan: PricingPlan }> = ({ plan }) => (
  <>
    <div className="mb-6">
      <div className="flex items-center justify-between mb-2">
        <span className="font-display text-xl font-bold text-white">{plan.name}</span>
        {plan.badge && !plan.popular && (
          <Badge variant="cyan">{plan.badge}</Badge>
        )}
      </div>
      <p className="text-slate-500 text-sm">{plan.tagline}</p>
    </div>

    {/* Speed highlight */}
    <div className="mb-6 p-3 rounded-xl bg-white/[0.03] border border-white/[0.06] flex items-center gap-3">
      <div className="w-8 h-8 rounded-lg bg-brand-600/20 flex items-center justify-center flex-shrink-0">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#60a5fa" strokeWidth="2">
          <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </div>
      <div>
        <div className="text-lg font-display font-bold text-white">{plan.speed}</div>
        <div className="text-xs text-slate-500 font-mono">Kecepatan Download</div>
      </div>
    </div>

    {/* Price */}
    <div className="mb-6">
      <div className="flex items-baseline gap-1">
        <span className="font-display text-3xl font-extrabold text-white">
          {formatRupiah(plan.price)}
        </span>
        <span className="text-slate-500 text-sm">{plan.priceUnit}</span>
      </div>
    </div>

    {/* Features */}
    <ul className="space-y-3 mb-8 flex-1">
      {plan.features.map((f) => (
        <li key={f} className="flex items-start gap-2.5 text-sm text-slate-300">
          <div className="w-4 h-4 rounded-full bg-emerald-500/15 flex items-center justify-center flex-shrink-0 mt-0.5">
            <svg width="8" height="8" viewBox="0 0 12 12" fill="none">
              <path d="M2 6l3 3 5-5" stroke="#34d399" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
          {f}
        </li>
      ))}
      {plan.notIncluded?.map((f) => (
        <li key={f} className="flex items-start gap-2.5 text-sm text-slate-600">
          <div className="w-4 h-4 rounded-full bg-white/[0.03] flex items-center justify-center flex-shrink-0 mt-0.5">
            <svg width="8" height="8" viewBox="0 0 12 12" fill="none">
              <path d="M3 3l6 6M9 3l-6 6" stroke="#4b5563" strokeWidth="1.5" strokeLinecap="round" />
            </svg>
          </div>
          {f}
        </li>
      ))}
    </ul>

    <Button variant={plan.ctaVariant as "primary" | "secondary" | "outline"} size="md" href="#daftar" fullWidth>
      {plan.ctaLabel}
    </Button>
  </>
);

export const Pricing: React.FC = () => {
  return (
    <Section id="paket" className="relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-brand-950/20 to-transparent pointer-events-none" />

      <SectionHeader
        eyebrow="Paket Internet"
        title="Pilih Paket yang"
        titleHighlight="Sesuai Kebutuhan"
        description="Semua paket sudah termasuk instalasi gratis, perangkat router, dan akses ke streaming lokal NeucentraNet."
      />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-stretch">
        {plans.map((plan, index) => (
          <PricingCard key={plan.id} plan={plan} index={index} />
        ))}
      </div>

      <p className="text-center text-slate-600 text-sm mt-8 font-mono">
        * Harga belum termasuk PPN 11%. Syarat & ketentuan berlaku.
      </p>
    </Section>
  );
};
