import React from "react";
import { Section, SectionHeader } from "@/components/ui/Section";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";

interface Service {
  icon: React.ReactNode;
  title: string;
  description: string;
  features: string[];
  badge?: string;
  badgeVariant?: "blue" | "cyan" | "green" | "orange" | "purple";
  highlight?: boolean;
  cta: string;
  ctaHref: string;
}

const services: Service[] = [
  {
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
        <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z" strokeLinecap="round" strokeLinejoin="round" />
        <polyline points="9 22 9 12 15 12 15 22" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    ),
    title: "Internet Rumah",
    description:
      "Koneksi fiber optik langsung ke rumah Anda. Stabil, cepat, dan cocok untuk work-from-home, gaming, hingga streaming 4K.",
    features: ["Hingga 1Gbps", "WiFi 6 Router Gratis", "Tanpa Batas Data", "Instalasi Gratis"],
    cta: "Lihat Paket",
    ctaHref: "#paket",
    badgeVariant: "blue",
  },
  {
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
        <rect x="2" y="3" width="20" height="14" rx="2" strokeLinecap="round" />
        <path d="M8 21h8M12 17v4" strokeLinecap="round" />
      </svg>
    ),
    title: "Internet Bisnis",
    description:
      "Solusi konektivitas enterprise dengan SLA terjamin, IP dedicated, dan dukungan teknis prioritas untuk bisnis Anda.",
    features: ["IP Dedicated", "SLA 99.9%", "Bandwidth Simetris", "Dukungan 24/7 Prioritas"],
    badge: "Enterprise",
    badgeVariant: "cyan",
    cta: "Konsultasi",
    ctaHref: "#kontak",
  },
  {
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
        <polygon points="23 7 16 12 23 17 23 7" strokeLinecap="round" strokeLinejoin="round" />
        <rect x="1" y="5" width="15" height="14" rx="2" strokeLinecap="round" />
      </svg>
    ),
    title: "Streaming Lokal",
    description:
      "Platform streaming konten lokal Indonesia dengan latensi ultra-rendah. Nikmati hiburan terbaik tanpa buffering.",
    features: ["Konten Lokal HD/4K", "Latensi <2ms", "Tanpa Biaya Tambahan", "Eksklusif Pelanggan"],
    badge: "Unggulan",
    badgeVariant: "orange",
    highlight: true,
    cta: "Pelajari Lebih",
    ctaHref: "#layanan",
  },
];

const ServiceCard: React.FC<{ service: Service; index: number }> = ({
  service,
  index,
}) => {
  if (service.highlight) {
    return (
      <div
        className="relative rounded-2xl p-px bg-gradient-to-br from-brand-500/50 via-accent-cyan/30 to-brand-600/50 animate-fade-up"
        style={{ animationDelay: `${index * 100}ms` }}
      >
        <div className="relative rounded-[15px] bg-gradient-to-br from-brand-950/90 to-surface-950/90 p-8 h-full">
          {/* Glow top */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-px bg-gradient-to-r from-transparent via-accent-cyan/60 to-transparent" />

          <div className="flex items-start justify-between mb-5">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-brand-600 to-accent-cyan flex items-center justify-center text-white shadow-glow-blue">
              {service.icon}
            </div>
            {service.badge && (
              <Badge variant={service.badgeVariant}>{service.badge}</Badge>
            )}
          </div>

          <h3 className="font-display text-xl font-bold text-white mb-3">
            {service.title}
          </h3>
          <p className="text-slate-400 text-sm leading-relaxed mb-6">
            {service.description}
          </p>

          <ul className="space-y-2.5 mb-7">
            {service.features.map((f) => (
              <li key={f} className="flex items-center gap-2.5 text-sm text-slate-300">
                <div className="w-4 h-4 rounded-full bg-brand-600/20 flex items-center justify-center flex-shrink-0">
                  <svg width="8" height="8" viewBox="0 0 12 12" fill="none">
                    <path d="M2 6l3 3 5-5" stroke="#60a5fa" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
                {f}
              </li>
            ))}
          </ul>

          <Button variant="primary" size="md" href={service.ctaHref} fullWidth>
            {service.cta}
          </Button>
        </div>
      </div>
    );
  }

  return (
    <Card
      hover
      padding="lg"
      className="animate-fade-up"
    >
      <div className="flex items-start justify-between mb-5">
        <div className="w-14 h-14 rounded-2xl bg-white/[0.04] border border-white/[0.08] flex items-center justify-center text-brand-400">
          {service.icon}
        </div>
        {service.badge && (
          <Badge variant={service.badgeVariant}>{service.badge}</Badge>
        )}
      </div>

      <h3 className="font-display text-xl font-bold text-white mb-3">
        {service.title}
      </h3>
      <p className="text-slate-400 text-sm leading-relaxed mb-6">
        {service.description}
      </p>

      <ul className="space-y-2.5 mb-7">
        {service.features.map((f) => (
          <li key={f} className="flex items-center gap-2.5 text-sm text-slate-300">
            <div className="w-4 h-4 rounded-full bg-white/[0.04] flex items-center justify-center flex-shrink-0">
              <svg width="8" height="8" viewBox="0 0 12 12" fill="none">
                <path d="M2 6l3 3 5-5" stroke="#60a5fa" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
            {f}
          </li>
        ))}
      </ul>

      <Button variant="outline" size="md" href={service.ctaHref} fullWidth>
        {service.cta}
      </Button>
    </Card>
  );
};

export const Services: React.FC = () => {
  return (
    <Section id="layanan" className="relative">
      {/* Subtle divider */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-px h-20 bg-gradient-to-b from-transparent via-brand-600/30 to-transparent" />

      <SectionHeader
        eyebrow="Layanan Kami"
        title="Semua yang Anda Butuhkan,"
        titleHighlight="Dalam Satu Ekosistem"
        description="Dari rumah hingga korporasi, kami menyediakan solusi konektivitas terbaik dengan teknologi fiber optik terkini."
      />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {services.map((service, index) => (
          <ServiceCard key={service.title} service={service} index={index} />
        ))}
      </div>
    </Section>
  );
};
