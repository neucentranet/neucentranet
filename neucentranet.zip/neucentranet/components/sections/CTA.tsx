import React from "react";
import { Button } from "@/components/ui/Button";

export const CTA: React.FC = () => {
  return (
    <section id="daftar" className="py-20 md:py-28 px-4 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-brand-900/40 via-surface-950 to-brand-950/30 pointer-events-none" />
      <div className="absolute inset-0 bg-grid-pattern bg-grid opacity-30 pointer-events-none" />

      {/* Orbs */}
      <div className="absolute top-0 left-1/4 w-80 h-80 rounded-full bg-brand-600/15 blur-[100px] pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-64 h-64 rounded-full bg-accent-cyan/10 blur-[80px] pointer-events-none" />

      <div className="max-w-4xl mx-auto text-center relative z-10">
        {/* Eyebrow */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-brand-600/30 bg-brand-950/60 backdrop-blur-sm mb-8">
          <span className="w-2 h-2 rounded-full bg-brand-400 animate-pulse" />
          <span className="text-xs font-mono tracking-widest text-brand-300 uppercase">
            Bergabung Sekarang
          </span>
        </div>

        <h2 className="font-display text-4xl sm:text-5xl md:text-6xl font-extrabold text-white leading-tight mb-6">
          Gabung dengan{" "}
          <span className="text-gradient">NeucentraNet</span>
          <br />
          Sekarang
        </h2>

        <p className="text-slate-400 text-lg max-w-xl mx-auto leading-relaxed mb-10">
          Ribuan pelanggan sudah menikmati internet cepat, stabil, dan layanan digital terintegrasi dari NeucentraNet. Giliran Anda.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
          <Button
            variant="primary"
            size="lg"
            href="https://wa.me/6281234567890?text=Halo%20NeucentraNet%2C%20saya%20ingin%20mendaftar"
            icon={
              <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
              </svg>
            }
            iconPosition="left"
          >
            Daftar via WhatsApp
          </Button>
          <Button variant="outline" size="lg" href="#paket">
            Lihat Paket Dulu
          </Button>
        </div>

        {/* Trust badges */}
        <div className="flex flex-wrap items-center justify-center gap-6 text-slate-600 text-sm font-mono">
          {[
            "✓ Tanpa kontrak jangka panjang",
            "✓ Instalasi gratis",
            "✓ 14 hari uji coba",
          ].map((item) => (
            <span key={item} className="flex items-center gap-1.5 text-slate-500">
              {item}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
};
