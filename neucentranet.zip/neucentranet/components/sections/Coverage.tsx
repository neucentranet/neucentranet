import React from "react";
import { Section, SectionHeader } from "@/components/ui/Section";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";

interface CoverageArea {
  city: string;
  province: string;
  status: "aktif" | "segera" | "beta";
  coverage: number; // percentage
  zones: number;
}

const coverageAreas: CoverageArea[] = [
  { city: "Jakarta Selatan", province: "DKI Jakarta", status: "aktif", coverage: 95, zones: 48 },
  { city: "Jakarta Barat", province: "DKI Jakarta", status: "aktif", coverage: 88, zones: 42 },
  { city: "Depok", province: "Jawa Barat", status: "aktif", coverage: 76, zones: 35 },
  { city: "Tangerang Selatan", province: "Banten", status: "aktif", coverage: 70, zones: 31 },
  { city: "Bekasi", province: "Jawa Barat", status: "beta", coverage: 45, zones: 18 },
  { city: "Bogor", province: "Jawa Barat", status: "beta", coverage: 30, zones: 12 },
  { city: "Bandung", province: "Jawa Barat", status: "segera", coverage: 0, zones: 0 },
  { city: "Surabaya", province: "Jawa Timur", status: "segera", coverage: 0, zones: 0 },
];

const statusConfig = {
  aktif: { label: "Aktif", variant: "green" as const, dot: "bg-emerald-400" },
  segera: { label: "Segera", variant: "orange" as const, dot: "bg-orange-400" },
  beta: { label: "Beta", variant: "cyan" as const, dot: "bg-cyan-400" },
};

const CoverageRow: React.FC<{ area: CoverageArea; index: number }> = ({
  area,
  index,
}) => {
  const config = statusConfig[area.status];
  return (
    <div
      className="flex items-center gap-4 p-4 rounded-xl bg-white/[0.02] border border-white/[0.04] hover:bg-white/[0.04] hover:border-white/[0.08] transition-all duration-200 animate-fade-up"
      style={{ animationDelay: `${index * 60}ms` }}
    >
      {/* Status dot */}
      <div className={`w-2 h-2 rounded-full flex-shrink-0 ${config.dot} ${area.status === 'aktif' ? 'animate-pulse' : ''}`} />

      {/* Location */}
      <div className="flex-1 min-w-0">
        <div className="font-medium text-white text-sm truncate">{area.city}</div>
        <div className="text-slate-500 text-xs font-mono">{area.province}</div>
      </div>

      {/* Coverage bar */}
      {area.coverage > 0 && (
        <div className="hidden sm:flex items-center gap-2 flex-shrink-0">
          <div className="w-24 h-1.5 rounded-full bg-white/[0.06] overflow-hidden">
            <div
              className="h-full rounded-full bg-gradient-to-r from-brand-600 to-accent-cyan"
              style={{ width: `${area.coverage}%` }}
            />
          </div>
          <span className="text-xs text-slate-500 font-mono w-8">{area.coverage}%</span>
        </div>
      )}

      {/* Zones */}
      {area.zones > 0 && (
        <div className="hidden md:block text-xs text-slate-500 font-mono flex-shrink-0">
          {area.zones} zona
        </div>
      )}

      {/* Status badge */}
      <Badge variant={config.variant}>{config.label}</Badge>
    </div>
  );
};

export const Coverage: React.FC = () => {
  return (
    <Section id="coverage" className="relative">
      <SectionHeader
        eyebrow="Jangkauan Jaringan"
        title="Coverage Area"
        titleHighlight="NeucentraNet"
        description="Jaringan kami terus berkembang. Cek ketersediaan layanan di area Anda atau daftarkan lokasi untuk prioritas ekspansi."
      />

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Map placeholder */}
        <div className="lg:col-span-3">
          <Card padding="none" className="overflow-hidden h-full min-h-[400px]">
            <div className="relative h-full min-h-[400px] bg-gradient-to-br from-surface-900 to-surface-950 flex items-center justify-center">
              {/* Decorative map grid */}
              <div className="absolute inset-0 bg-grid-pattern bg-grid opacity-50" />

              {/* Fake map dots */}
              <div className="absolute inset-0">
                {[
                  { top: "35%", left: "48%", size: "lg", active: true },
                  { top: "42%", left: "43%", size: "md", active: true },
                  { top: "48%", left: "52%", size: "md", active: true },
                  { top: "38%", left: "55%", size: "sm", active: false },
                  { top: "55%", left: "46%", size: "sm", active: false },
                ].map((dot, i) => (
                  <div
                    key={i}
                    className="absolute -translate-x-1/2 -translate-y-1/2"
                    style={{ top: dot.top, left: dot.left }}
                  >
                    {dot.active && (
                      <div
                        className={`rounded-full bg-brand-500/20 animate-ping absolute inset-0 ${
                          dot.size === "lg" ? "w-12 h-12 -m-5" : dot.size === "md" ? "w-8 h-8 -m-3" : "w-6 h-6 -m-2"
                        }`}
                      />
                    )}
                    <div
                      className={`rounded-full ${dot.active ? "bg-brand-500 shadow-glow-blue" : "bg-slate-600"} ${
                        dot.size === "lg" ? "w-4 h-4" : dot.size === "md" ? "w-3 h-3" : "w-2 h-2"
                      }`}
                    />
                  </div>
                ))}
              </div>

              {/* Center content */}
              <div className="relative z-10 text-center px-8">
                <div className="w-16 h-16 rounded-2xl bg-brand-600/15 border border-brand-600/30 flex items-center justify-center mx-auto mb-4">
                  <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#60a5fa" strokeWidth="1.5">
                    <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z" />
                    <circle cx="12" cy="9" r="2.5" />
                  </svg>
                </div>
                <h3 className="font-display font-bold text-white mb-2">Peta Interaktif</h3>
                <p className="text-slate-500 text-sm mb-4">
                  Peta coverage real-time segera hadir
                </p>
                <Button variant="outline" size="sm" href="#kontak">
                  Cek Lokasi Saya
                </Button>
              </div>
            </div>
          </Card>
        </div>

        {/* Area list */}
        <div className="lg:col-span-2 space-y-2">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm text-slate-400 font-mono">{coverageAreas.length} kota terjangkau</span>
            <div className="flex items-center gap-3 text-xs text-slate-600 font-mono">
              <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />Aktif</span>
              <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />Beta</span>
              <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-orange-400" />Segera</span>
            </div>
          </div>
          {coverageAreas.map((area, index) => (
            <CoverageRow key={area.city} area={area} index={index} />
          ))}
        </div>
      </div>

      {/* CTA */}
      <div className="mt-10 text-center">
        <p className="text-slate-500 text-sm mb-4">
          Kota Anda belum terdaftar?
        </p>
        <Button variant="secondary" size="md" href="#kontak">
          Daftarkan Lokasi Saya
        </Button>
      </div>
    </Section>
  );
};
