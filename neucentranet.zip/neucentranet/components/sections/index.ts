export { Navbar } from "./Navbar";
export { Hero } from "./Hero";
export { Services } from "./Services";
export { Pricing } from "./Pricing";
export { Coverage } from "./Coverage";
export { Advantages } from "./Advantages";
export { CTA } from "./CTA";
export { Footer } from "./Footer";
