import React from "react";
import { Button } from "@/components/ui/Button";

const stats = [
  { value: "10Gbps", label: "Kapasitas Backbone" },
  { value: "99.9%", label: "Uptime Garansi" },
  { value: "<5ms", label: "Latensi Lokal" },
  { value: "24/7", label: "Dukungan Teknis" },
];

export const Hero: React.FC = () => {
  return (
    <section
      id="beranda"
      className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20"
    >
      {/* Background Effects */}
      <div className="absolute inset-0 bg-grid-pattern bg-grid opacity-100" />
      <div className="absolute inset-0 bg-hero-gradient" />

      {/* Floating orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-brand-600/10 blur-[120px] animate-float" />
      <div
        className="absolute bottom-1/4 right-1/4 w-80 h-80 rounded-full bg-accent-cyan/8 blur-[100px] animate-float"
        style={{ animationDelay: "3s" }}
      />
      <div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-brand-900/20 blur-[80px]"
      />

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 text-center">
        {/* Eyebrow */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-brand-600/30 bg-brand-950/60 backdrop-blur-sm mb-8 animate-fade-up">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-xs font-mono tracking-widest text-brand-300 uppercase">
            Jaringan Fiber Optik Premium
          </span>
        </div>

        {/* Headline */}
        <h1
          className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold text-white leading-[1.08] tracking-tight mb-6 animate-fade-up"
          style={{ animationDelay: "100ms" }}
        >
          Internet{" "}
          <span className="text-gradient">Cepat, Stabil,</span>
          <br />
          dan Terintegrasi
        </h1>

        {/* Subtext */}
        <p
          className="text-slate-400 text-lg md:text-xl max-w-2xl mx-auto leading-relaxed mb-10 animate-fade-up"
          style={{ animationDelay: "200ms" }}
        >
          ISP modern Indonesia dengan ekosistem digital lengkap — dari internet
          rumah hingga streaming lokal, semua dalam satu platform.
        </p>

        {/* CTA Buttons */}
        <div
          className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16 animate-fade-up"
          style={{ animationDelay: "300ms" }}
        >
          <Button
            variant="primary"
            size="lg"
            href="#coverage"
            icon={
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z" />
                <circle cx="12" cy="9" r="2.5" />
              </svg>
            }
            iconPosition="left"
          >
            Cek Coverage
          </Button>
          <Button variant="secondary" size="lg" href="#daftar">
            Daftar Sekarang
          </Button>
        </div>

        {/* Stats */}
        <div
          className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto animate-fade-up"
          style={{ animationDelay: "400ms" }}
        >
          {stats.map((stat) => (
            <div
              key={stat.label}
              className="glassmorphism rounded-2xl p-4 text-center"
            >
              <div className="font-display text-2xl font-bold text-gradient mb-1">
                {stat.value}
              </div>
              <div className="text-xs text-slate-500 font-mono">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Scroll hint */}
        <div className="mt-16 flex flex-col items-center gap-2 text-slate-600 animate-float">
          <span className="text-xs font-mono tracking-widest">SCROLL</span>
          <div className="w-px h-8 bg-gradient-to-b from-slate-600 to-transparent" />
        </div>
      </div>
    </section>
  );
};
