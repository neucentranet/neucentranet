import React from "react";

interface SectionProps {
  children: React.ReactNode;
  className?: string;
  id?: string;
  fullWidth?: boolean;
}

export const Section: React.FC<SectionProps> = ({
  children,
  className = "",
  id,
  fullWidth = false,
}) => {
  return (
    <section id={id} className={["py-20 md:py-28 px-4", className].join(" ")}>
      <div className={fullWidth ? "w-full" : "max-w-7xl mx-auto"}>
        {children}
      </div>
    </section>
  );
};

interface SectionHeaderProps {
  eyebrow?: string;
  title: string;
  titleHighlight?: string;
  description?: string;
  center?: boolean;
}

export const SectionHeader: React.FC<SectionHeaderProps> = ({
  eyebrow,
  title,
  titleHighlight,
  description,
  center = true,
}) => {
  return (
    <div className={["mb-14 md:mb-16", center ? "text-center" : ""].join(" ")}>
      {eyebrow && (
        <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-mono font-medium tracking-widest uppercase text-brand-400 border border-brand-600/30 bg-brand-950/50 mb-4">
          <span className="w-1.5 h-1.5 rounded-full bg-brand-400 animate-pulse" />
          {eyebrow}
        </span>
      )}
      <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight">
        {title}{" "}
        {titleHighlight && (
          <span className="text-gradient">{titleHighlight}</span>
        )}
      </h2>
      {description && (
        <p className="mt-4 text-slate-400 text-lg max-w-2xl leading-relaxed mx-auto">
          {description}
        </p>
      )}
    </div>
  );
};
