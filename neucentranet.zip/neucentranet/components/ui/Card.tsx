import React from "react";

interface CardProps {
  children: React.ReactNode;
  className?: string;
  hover?: boolean;
  glow?: boolean;
  padding?: "sm" | "md" | "lg" | "none";
}

const paddingClasses = {
  none: "",
  sm: "p-4",
  md: "p-6",
  lg: "p-8",
};

export const Card: React.FC<CardProps> = ({
  children,
  className = "",
  hover = false,
  glow = false,
  padding = "md",
}) => {
  return (
    <div
      className={[
        "relative rounded-2xl border border-white/[0.07] bg-card-gradient",
        "bg-white/[0.02] shadow-card",
        hover
          ? "transition-all duration-300 hover:shadow-card-hover hover:border-white/[0.12] hover:-translate-y-1"
          : "",
        glow ? "hover:shadow-glow-blue" : "",
        paddingClasses[padding],
        className,
      ]
        .filter(Boolean)
        .join(" ")}
    >
      {children}
    </div>
  );
};
