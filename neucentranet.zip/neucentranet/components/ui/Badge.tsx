import React from "react";

interface BadgeProps {
  children: React.ReactNode;
  variant?: "blue" | "cyan" | "green" | "orange" | "purple";
  className?: string;
}

const variantClasses = {
  blue: "text-brand-300 border-brand-500/30 bg-brand-950/50",
  cyan: "text-cyan-300 border-cyan-500/30 bg-cyan-950/50",
  green: "text-emerald-300 border-emerald-500/30 bg-emerald-950/50",
  orange: "text-orange-300 border-orange-500/30 bg-orange-950/50",
  purple: "text-purple-300 border-purple-500/30 bg-purple-950/50",
};

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = "blue",
  className = "",
}) => {
  return (
    <span
      className={[
        "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border font-mono",
        variantClasses[variant],
        className,
      ].join(" ")}
    >
      {children}
    </span>
  );
};
