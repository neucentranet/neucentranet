# NeucentraNet — Landing Page

ISP modern Indonesia. Next.js 14 App Router + TypeScript + Tailwind CSS.

## Cara Menjalankan

```bash
# Install dependencies
npm install

# Development
npm run dev

# Build production
npm run build
npm start
```

Buka [http://localhost:3000](http://localhost:3000)

---

## Struktur Proyek

```
neucentranet/
├── app/
│   ├── layout.tsx              # Root layout + metadata
│   ├── globals.css             # Global styles, font imports, utilities
│   ├── (landing)/
│   │   ├── layout.tsx          # Landing layout wrapper
│   │   └── page.tsx            # Halaman utama — merakit semua seksi
│   └── (dashboard)/
│       ├── layout.tsx          # Dashboard layout (placeholder)
│       └── dashboard/
│           └── page.tsx        # Dashboard pelanggan (placeholder)
│
├── components/
│   ├── ui/                     # Komponen reusable primitif
│   │   ├── Button.tsx          # Tombol dengan 4 varian + ukuran
│   │   ├── Card.tsx            # Card container dengan efek hover/glow
│   │   ├── Section.tsx         # Section wrapper + SectionHeader
│   │   ├── Badge.tsx           # Badge/label kecil berwarna
│   │   └── index.ts            # Barrel export
│   │
│   └── sections/               # Seksi-seksi halaman landing
│       ├── Navbar.tsx          # Navigasi sticky + mobile menu
│       ├── Hero.tsx            # Hero utama + stats
│       ├── Services.tsx        # 3 layanan (Rumah, Bisnis, Streaming)
│       ├── Pricing.tsx         # 3 paket harga (Basic/Pro/Ultra)
│       ├── Coverage.tsx        # Area coverage + peta placeholder
│       ├── Advantages.tsx      # 6 keunggulan NeucentraNet
│       ├── CTA.tsx             # Call-to-action penutup
│       ├── Footer.tsx          # Footer + kontak + sosmed
│       └── index.ts            # Barrel export
│
├── tailwind.config.ts          # Design tokens (warna, font, animasi)
├── tsconfig.json
├── next.config.mjs
└── package.json
```

---

## Design System

### Warna Utama
- **Brand Blue**: `brand-600` (#2563eb) — aksi utama
- **Accent Cyan**: `accent-cyan` (#06b6d4) — aksen & highlight  
- **Surface**: `surface-950` (#05080f) — background utama

### Font
- **Display** (judul): Syne — bold, geometric
- **Body** (teks): DM Sans — bersih, modern
- **Mono** (label, kode): JetBrains Mono

### Komponen Utama
| Komponen | Varian |
|----------|--------|
| `Button` | `primary`, `secondary`, `ghost`, `outline` |
| `Card` | `hover`, `glow`, padding `sm/md/lg` |
| `Badge` | `blue`, `cyan`, `green`, `orange`, `purple` |
| `Section` | + `SectionHeader` dengan eyebrow/title/description |

---

## Pengembangan Selanjutnya

### Phase 2 — Auth & Dashboard
```
app/
├── (auth)/
│   ├── login/page.tsx
│   └── register/page.tsx
└── (dashboard)/
    └── dashboard/
        ├── page.tsx       # Overview pelanggan
        ├── billing/       # Tagihan & pembayaran
        ├── usage/         # Statistik penggunaan
        └── tickets/       # Dukungan pelanggan
```

### Phase 3 — Fitur Lanjutan
- Integrasi payment gateway (Midtrans/Xendit)
- Real-time usage monitoring (WebSocket)
- Peta coverage interaktif (Mapbox/Google Maps)
- Notifikasi gangguan otomatis
- Self-service trouble ticket

---

## Kontak Developer
Proyek ini siap dikembangkan lebih lanjut. Semua komponen dirancang modular dan mudah di-extend.
